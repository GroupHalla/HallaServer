#!/usr/bin/env bash
sudo apt-get update -qq && sudo apt-get install -y libqt6core6t64 libqt6network6t64
echo "Dependências OK. Rode: ./halla-server --config halla-server.ini"
